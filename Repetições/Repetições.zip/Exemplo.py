

number = int(0);
limit = int(0);

limit = int(input("Digite o limite da repetição: "));

while ( number <= limit ):
    print(number);

    number = number + 1;





