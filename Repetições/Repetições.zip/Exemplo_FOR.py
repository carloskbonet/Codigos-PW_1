# Variáveis

print("O algoritmo exibirá os números de 0 a 10.\n");

# Inputs


# Processamento

for contador in range( 0 , 11 , 1 ):
    print(contador);