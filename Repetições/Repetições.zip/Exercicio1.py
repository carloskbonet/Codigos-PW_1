
counter = int(0);

print("O algoritmo abaixo fará uma contagem regressiva.");

counter = int(input("Digite o valor inicial: "));

# Processamento

while( counter >= 0 ):
    print(counter);

    counter = counter -1;