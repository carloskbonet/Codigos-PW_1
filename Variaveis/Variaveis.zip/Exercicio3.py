
celsius = float(0);
fahrenheit = float(0);

print("\nO algoritmo converte a temperatura digitada em °C para °F.");

celsius = float(input("Temperatura °C : "));

fahrenheit = (celsius * 1.8) + 32;

print(f"\nTemperatura Convertida para °F : {fahrenheit}\n");